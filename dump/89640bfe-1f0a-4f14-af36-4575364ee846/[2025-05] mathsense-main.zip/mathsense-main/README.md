# mathsense

an alternative to mathtrainer, currently in development.

![mathsense](./doc/image.png)

## Features
- Library
- - ~~Question Bank~~
- Visuals ~~basic~~

