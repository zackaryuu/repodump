
class QPart{
  String? get text => null;
}

class QString extends QPart{
  @override
  final String text;

  QString({required this.text});
}

class QField extends QPart{
  final String tooltip;
  final int inputLength;
  final bool hasMin;
  final bool hasMax;
  final int? minValue;
  final int? maxValue;

  QField({
    required this.tooltip, 
    required this.inputLength, 
    this.hasMin = false, 
    this.hasMax = false, 
    this.minValue, 
    this.maxValue});
}

class QRow{
  final List<QPart> parts;

  QRow({required this.parts});
}

class Q{
  final List<QRow> rows;
  //check answer function, take list of field answers
  final bool Function(List<int>) checkAnswer;
  Q({required this.rows, required this.checkAnswer});  
}