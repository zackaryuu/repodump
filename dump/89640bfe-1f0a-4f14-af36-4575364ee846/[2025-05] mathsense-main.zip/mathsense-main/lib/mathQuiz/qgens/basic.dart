import '../models/q.dart';
import 'base.dart';
import 'dart:math';

class BasicArithmetic extends BaseQuestionGenerator {
  static final _rand = Random();

  // 1: x + y = [] (x, y <= 10)
  static Q difficulty1() {
    int x = _rand.nextInt(11); // 0..10
    int y = _rand.nextInt(11 - x); // 0..(10-x)
    int answer = x + y;
    return Q(
      rows: [
        QRow(parts: [
          QString(text: '$x'),
          QString(text: ' + '),
          QString(text: '$y'),
          QString(text: ' = '),
          QField(tooltip: 'Sum', inputLength: answer.toString().length),
        ])
      ],
      checkAnswer: (answers) => answers.isNotEmpty && answers[0] == answer,
    );
  }

  // 1_1: x - y = [] (x, y <= 20, x >= y)
  static Q difficulty1_1() {
    int x = _rand.nextInt(21); // 0..20
    int y = _rand.nextInt(x + 1); // 0..x
    int answer = x - y;
    return Q(
      rows: [
        QRow(parts: [
          QString(text: '$x'),
          QString(text: ' - '),
          QString(text: '$y'),
          QString(text: ' = '),
          QField(tooltip: 'Difference', inputLength: answer.toString().length),
        ])
      ],
      checkAnswer: (answers) => answers.isNotEmpty && answers[0] == answer,
    );
  }

  // 1_2: x × y = [] (x, y <= 5, product <= 20)
  static Q difficulty1_2() {
    int x, y;
    do {
      x = _rand.nextInt(5) + 1; // 1..5
      y = _rand.nextInt(5) + 1; // 1..5
    } while (x * y > 20);
    int answer = x * y;
    return Q(
      rows: [
        QRow(parts: [
          QString(text: '$x'),
          QString(text: ' × '),
          QString(text: '$y'),
          QString(text: ' = '),
          QField(tooltip: 'Product', inputLength: answer.toString().length),
        ])
      ],
      checkAnswer: (answers) => answers.isNotEmpty && answers[0] == answer,
    );
  }

  // 1_3: x ÷ y = [] (x, y <= 20, integer division, y != 0)
  static Q difficulty1_3() {
    int y = _rand.nextInt(9) + 1; // 1..9
    int result = _rand.nextInt(3) + 1; // 1..3
    int x = y * result; // ensures integer division
    while (x > 20) {
      y = _rand.nextInt(9) + 1;
      result = _rand.nextInt(3) + 1;
      x = y * result;
    }
    return Q(
      rows: [
        QRow(parts: [
          QString(text: '$x'),
          QString(text: ' ÷ '),
          QString(text: '$y'),
          QString(text: ' = '),
          QField(tooltip: 'Quotient', inputLength: result.toString().length),
        ])
      ],
      checkAnswer: (answers) => answers.isNotEmpty && answers[0] == result,
    );
  }

  @override
  Map<String, Q Function()> get difficultyFunctions => {
    '1': difficulty1,
    '1_1': difficulty1_1,
    '1_2': difficulty1_2,
    '1_3': difficulty1_3,
  };
}
