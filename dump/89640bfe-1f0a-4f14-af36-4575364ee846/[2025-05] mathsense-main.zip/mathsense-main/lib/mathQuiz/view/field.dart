import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class NumericInputField extends StatefulWidget {
  final int maxLength;
  final int minValue;
  final int maxValue;
  final TextEditingController? controller;
  final String? label;
  final String? hint;
  final Function(int)? onChanged;
  final Function()? onFail;
  final TextStyle? style;

  const NumericInputField({
    super.key,
    this.maxLength = -1,
    this.minValue = -9223372036854775808, // int.minFinite equivalent
    this.maxValue = 9223372036854775807,  // int.maxFinite equivalent
    this.controller,
    this.label,
    this.hint,
    this.onChanged,
    this.onFail,
    this.style,
  });

  @override
  State<NumericInputField> createState() => _NumericInputFieldState();
}

class _NumericInputFieldState extends State<NumericInputField> {
  late TextEditingController _controller;
  bool _isValid = true;

  @override
  void initState() {
    super.initState();
    _controller = widget.controller ?? TextEditingController();
  }

  @override
  void dispose() {
    if (widget.controller == null) {
      _controller.dispose();
    }
    super.dispose();
  }

  bool _validateValue(String value) {
    if (value.isEmpty) return true;
    
    // Handle negative sign at the start
    if (value == '-') return true;
    
    final number = int.tryParse(value);
    if (number == null) return false;

    if (widget.minValue != -9223372036854775808 && number < widget.minValue) return false;
    if (widget.maxValue != 9223372036854775807 && number > widget.maxValue) return false;
    
    return true;
  }

  double _calculateWidth() {
    // Base width for a single digit
    final baseWidth = 80.0;
    // Additional width per character
    final charWidth = 40.0;
    // Get the effective length (use maxLength if specified, otherwise use a default)
    // Always add 1 for extra padding
    final effectiveLength = (widget.maxLength > 0 ? widget.maxLength : 3) + 1;
    // Calculate total width
    return baseWidth + (charWidth * effectiveLength);
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: _calculateWidth(),
      child: TextField(
        controller: _controller,
        keyboardType: const TextInputType.numberWithOptions(signed: true),
        style: widget.style,
        textAlign: TextAlign.center,
        inputFormatters: [
          FilteringTextInputFormatter.allow(RegExp(r'^-?\d*$')),
          if (widget.maxLength != -1)
            LengthLimitingTextInputFormatter(widget.maxLength),
        ],
        decoration: InputDecoration(
          labelText: widget.label,
          hintText: widget.hint,
          contentPadding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(
              color: _isValid ? Colors.grey : Colors.red,
              width: 2,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide(
              color: _isValid ? Theme.of(context).primaryColor : Colors.red,
              width: 2,
            ),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(
              color: Colors.red,
              width: 2,
            ),
          ),
        ),
        onChanged: (value) {
          final isValid = _validateValue(value);
          if (isValid != _isValid) {
            setState(() {
              _isValid = isValid;
            });
            if (!isValid) {
              _controller.clear();
              widget.onFail?.call();
            }
          }
          
          if (isValid && value.isNotEmpty && value != '-') {
            widget.onChanged?.call(int.parse(value));
          }
        },
      ),
    );
  }
}
