import 'package:flutter/material.dart';
import '../qgen.dart';
import '../models/q.dart';

class QuizBrowser extends StatefulWidget {
  final QGen questionGenerator;
  final int totalQuestions;

  const QuizBrowser({
    super.key,
    required this.questionGenerator,
    this.totalQuestions = 10,
  });

  @override
  State<QuizBrowser> createState() => _QuizBrowserState();
}

class _QuizBrowserState extends State<QuizBrowser> {
  late List<Q> questions;
  late List<QuestionState> questionStates;
  int currentQuestionIndex = 0;

  @override
  void initState() {
    super.initState();
    _initializeQuiz();
  }

  void _initializeQuiz() {
    questions = widget.questionGenerator.generateQuestions(10);
    questionStates = List.generate(
      questions.length,
      (index) => QuestionState(
        question: questions[index],
        attempts: 0,
        isCorrect: false,
      ),
    );
  }

  void _handleAnswer(List<int> answers) {
    setState(() {
      final currentState = questionStates[currentQuestionIndex];
      currentState.attempts++;
      
      // Check if answer is correct
      final isCorrect = questions[currentQuestionIndex].checkAnswer(answers);
      currentState.isCorrect = isCorrect;

      // Move to next question if correct or after 3 attempts
      if (isCorrect || currentState.attempts >= 3) {
        if (currentQuestionIndex < questions.length - 1) {
          currentQuestionIndex++;
        }
      }
    });
  }

  void _restartQuiz() {
    setState(() {
      _initializeQuiz();
      currentQuestionIndex = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Math Quiz'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _restartQuiz,
          ),
        ],
      ),
      body: Column(
        children: [
          // Progress indicator
          LinearProgressIndicator(
            value: (currentQuestionIndex + 1) / questions.length,
          ),
          
          // Question counter
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              'Question ${currentQuestionIndex + 1} of ${questions.length}',
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ),

          // Question display
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  // Question card
                  Expanded(
                    child: QuestionCard(
                      question: questions[currentQuestionIndex],
                      onAnswer: _handleAnswer,
                    ),
                  ),
                  
                  // Attempts counter
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      'Attempts: ${questionStates[currentQuestionIndex].attempts}/3',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ),

                  // Feedback message
                  if (questionStates[currentQuestionIndex].isCorrect)
                    const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        'Correct!',
                        style: TextStyle(
                          color: Colors.green,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class QuestionState {
  final Q question;
  int attempts;
  bool isCorrect;

  QuestionState({
    required this.question,
    this.attempts = 0,
    this.isCorrect = false,
  });
}

class QuestionCard extends StatefulWidget {
  final Q question;
  final Function(List<int>) onAnswer;

  const QuestionCard({
    super.key,
    required this.question,
    required this.onAnswer,
  });

  @override
  State<QuestionCard> createState() => _QuestionCardState();
}

class _QuestionCardState extends State<QuestionCard> {
  final List<TextEditingController> _controllers = [];
  final List<FocusNode> _focusNodes = [];
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    // Initialize controllers and focus nodes for each QField in the question
    for (var row in widget.question.rows) {
      for (var part in row.parts) {
        if (part is QField) {
          _controllers.add(TextEditingController());
          _focusNodes.add(FocusNode());
        }
      }
    }
  }

  @override
  void dispose() {
    for (var controller in _controllers) {
      controller.dispose();
    }
    for (var node in _focusNodes) {
      node.dispose();
    }
    super.dispose();
  }

  void _submitAnswer() {
    List<int> answers = [];
    bool hasError = false;

    // Collect all answers and validate them
    for (var controller in _controllers) {
      final value = controller.text.trim();
      if (value.isEmpty) {
        setState(() {
          errorMessage = 'Please fill in all fields';
        });
        hasError = true;
        break;
      }

      final number = int.tryParse(value);
      if (number == null) {
        setState(() {
          errorMessage = 'Please enter valid numbers';
        });
        hasError = true;
        break;
      }

      answers.add(number);
    }

    if (!hasError) {
      setState(() {
        errorMessage = null;
      });
      widget.onAnswer(answers);
      
      // Clear all fields
      for (var controller in _controllers) {
        controller.clear();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // Calculate the font size based on the number of rows, with a minimum of 36px
    final fontSize = 36.0 + (widget.question.rows.length * 2.0);
    
    // Find the maximum input length in the question
    int maxInputLength = 0;
    for (var row in widget.question.rows) {
      for (var part in row.parts) {
        if (part is QField && part.inputLength > maxInputLength) {
          maxInputLength = part.inputLength;
        }
      }
    }
    // Calculate width based on input length (n+1) * 40
    final fieldWidth = (maxInputLength + 1) * 40.0;

    return Card(
      child: Column(
        children: [
          // Tooltip ribbon on top of the card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            color: Colors.blue,
            child: Center(
              child: Text(
                'Tooltip: ${widget.question.rows.first.parts.whereType<QField>().first.tooltip}',
                style: TextStyle(fontSize: fontSize * 0.5, color: Colors.white),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                ...widget.question.rows.map((row) {
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: row.parts.map((part) {
                      if (part is QString) {
                        return Text(
                          part.text,
                          style: TextStyle(fontSize: fontSize),
                        );
                      } else if (part is QField) {
                        int index = _controllers.length - 1;
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4.0),
                          child: SizedBox(
                            width: fieldWidth,
                            child: TextField(
                              controller: _controllers[index],
                              focusNode: _focusNodes[index],
                              keyboardType: TextInputType.number,
                              maxLength: part.inputLength,
                              style: TextStyle(fontSize: fontSize * 1.5),
                              decoration: InputDecoration(
                                counterText: '',
                                errorText: errorMessage,
                                border: const OutlineInputBorder(),
                              ),
                              onSubmitted: (_) => _submitAnswer(),
                            ),
                          ),
                        );
                      }
                      return const SizedBox.shrink();
                    }).toList(),
                  );
                }).toList(),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: _submitAnswer,
                  child: const Text('Submit'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
