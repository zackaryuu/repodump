import 'models/q.dart';
import 'qgens/base.dart';
import 'qgens/basic.dart';

class QGen {

  
  // Map of generator names to their instances
  final Map<String, BaseQuestionGenerator> generators;
  
  // Map to track current difficulty levels for each generator
  final Map<String, int> currentLevels;
  
  // Map to store weights for each generator
  final Map<String, int> generatorWeights;

  /// Create a new QGen instance with optional initial configuration
  /// 
  /// [initialGenerators] - Map of generator names to their instances (default: {'basic': BasicArithmetic()})
  /// [initialLevels] - Map of generator names to their initial difficulty levels (default: {'basic': 1})
  /// [initialWeights] - Map of generator names to their initial weights (default: {'basic': 1})
  QGen({
    Map<String, BaseQuestionGenerator>? initialGenerators,
    Map<String, int>? initialLevels,
    Map<String, int>? initialWeights,
  }) : 
    generators = initialGenerators ?? {'basic': BasicArithmetic()},
    currentLevels = initialLevels ?? {'basic': 1},
    generatorWeights = initialWeights ?? {'basic': 1} {
    // Ensure all generators have corresponding levels and weights
    for (var name in generators.keys) {
      currentLevels.putIfAbsent(name, () => 1);
      generatorWeights.putIfAbsent(name, () => 1);
    }
  }

  /// Add a new generator with optional initial level and weight
  void addGenerator(String name, BaseQuestionGenerator generator, {int? initialLevel, int? initialWeight}) {
    generators[name] = generator;
    if (initialLevel != null) currentLevels[name] = initialLevel;
    if (initialWeight != null) generatorWeights[name] = initialWeight;
  }

  /// Remove a generator and its associated level and weight
  void removeGenerator(String name) {
    generators.remove(name);
    currentLevels.remove(name);
    generatorWeights.remove(name);
  }

  /// Set the weight for a specific generator
  void setGeneratorWeight(String generatorName, int weight) {
    if (generators.containsKey(generatorName)) {
      generatorWeights[generatorName] = weight;
    }
  }

  /// Set the current difficulty level for a specific generator
  void setGeneratorLevel(String generatorName, int level) {
    if (generators.containsKey(generatorName)) {
      currentLevels[generatorName] = level;
    }
  }

  /// Update multiple generator weights at once
  void updateGeneratorWeights(Map<String, int> weights) {
    for (var entry in weights.entries) {
      if (generators.containsKey(entry.key)) {
        generatorWeights[entry.key] = entry.value;
      }
    }
  }

  /// Update multiple generator levels at once
  void updateGeneratorLevels(Map<String, int> levels) {
    for (var entry in levels.entries) {
      if (generators.containsKey(entry.key)) {
        currentLevels[entry.key] = entry.value;
      }
    }
  }

  /// Generate questions based on current weights and difficulty levels
  List<Q> generateQuestions(int totalQuestions) {
    List<Q> questions = [];
    
    // Calculate total weight
    int totalWeight = generatorWeights.values.fold(0, (sum, weight) => sum + weight);
    
    // Generate questions based on weights
    for (var entry in generators.entries) {
      String generatorName = entry.key;
      BaseQuestionGenerator generator = entry.value;
      
      // Calculate number of questions for this generator based on its weight
      int numQuestions = ((generatorWeights[generatorName]! / totalWeight) * totalQuestions).round();
      
      // Generate questions for this generator
      for (int i = 0; i < numQuestions; i++) {
        int currentLevel = currentLevels[generatorName]!;
        try {
          Q question = generator.generateQuestion(currentLevel, 1, null);
          questions.add(question);
        } catch (e) {
          // If generation fails, try with a lower level
          Q question = generator.generateQuestion(1, 1, null);
          questions.add(question);
        }
      }
    }
    
    // If we didn't generate enough questions, fill the rest with basic questions
    while (questions.length < totalQuestions) {
      Q question = generators['basic']!.generateQuestion(1, 1, null);
      questions.add(question);
    }
    
    return questions;
  }

  /// Get all available difficulty levels for a specific generator
  List<int> getAvailableLevels(String generatorName) {
    if (!generators.containsKey(generatorName)) return [];
    
    var functions = generators[generatorName]!.difficultyFunctions;
    return functions.keys
        .map((key) => int.parse(key.split('_')[0]))
        .toSet()
        .toList()
        ..sort();
  }

  /// Get the current state of all generators
  Map<String, dynamic> getGeneratorState() {
    return {
      'currentLevels': Map<String, int>.from(currentLevels),
      'weights': Map<String, int>.from(generatorWeights),
      'generators': generators.keys.toList(),
    };
  }
}
