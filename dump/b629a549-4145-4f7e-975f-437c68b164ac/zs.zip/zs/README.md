# zs
 zack's personal shell

## Installation
```bash
python -m pip install git+https://github.com/z-uu/zs.git
```

## Usage
```bash
zs
```