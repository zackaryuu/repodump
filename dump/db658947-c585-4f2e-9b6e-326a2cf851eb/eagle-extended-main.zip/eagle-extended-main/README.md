# eagle-extended
 extending some not eagle features

## Currently supported features
- [x] open shell at item location
- [x] create eentity that can be used to hold other non indexed files
- [x] copy/move file to eentity
- [x] set/edit/delete custom fields
- [ ] support creating direct command badges
- [ ] advanced linking
- [ ] advanced parsing by spec