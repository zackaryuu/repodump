
class DttBloc {
  const DttBloc();
}

const dttBloc = DttBloc();
