class Cmds:
    def test(x):
        print(f"this provides a test function with param {x}")