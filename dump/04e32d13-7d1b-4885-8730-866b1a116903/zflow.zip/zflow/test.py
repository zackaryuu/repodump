
from zs.zflow import ZFlow

path = "test"

scheduler = ZFlow(path)
scheduler.run()

