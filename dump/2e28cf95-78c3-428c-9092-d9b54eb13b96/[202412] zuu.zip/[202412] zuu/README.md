> # project migrated to https://github.com/zwtil/zuu2/tree/main/PYTHON_PKG/std

# zuu
Zack's Useful Utilities

## Install
```bash
pip  install zuu
```

## Naming Conventions
* `_{name}` for class objects
* `{name}` for named utilities
* `{name}_` for extensions to modules

## Changelog
* `v3` breaking change

