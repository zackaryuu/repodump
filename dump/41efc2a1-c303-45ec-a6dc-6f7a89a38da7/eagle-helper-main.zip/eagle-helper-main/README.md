# eagle-helper
 
Eagle.cool Helper for plugin initialization, i18n efforts, and more.


## Installation

```bash
pip install eagle-helper
```

