# zus
 zack's useful shell
