import os

MOD_PATH = os.path.dirname(__file__)
