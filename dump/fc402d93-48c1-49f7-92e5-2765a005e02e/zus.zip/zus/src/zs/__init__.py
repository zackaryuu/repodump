import os

APP_CONFIG_PATH = os.path.join(os.path.expanduser("~"), ".zs")
