from ekring.cli import cli

cli()

