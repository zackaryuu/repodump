# zugen
 zack's useful (doc) generator

## install
```bash
pip install git+https://github.com/ZackaryW/zugen.git
```

## Usage
```bash
zugen
-d                          // debug
gen
-uc                         // use zucacher
--profile "@/awe2024tex"    // @ is cacher reference syntax
--data "@/example-data/data.toml" 

```