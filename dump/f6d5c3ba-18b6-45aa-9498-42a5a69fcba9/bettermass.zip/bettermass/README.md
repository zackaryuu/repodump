# BetterMass
This is the bettermass-core package repository.

## Installation
```bash
npm install bettermass-core
```

