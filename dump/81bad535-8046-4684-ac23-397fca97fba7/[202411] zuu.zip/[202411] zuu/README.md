> Project archived, see https://github.com/zwtil/zuu for newest implementations

# zuu
zack's useful utilities

## install
```
pip install zuu
```

## Mapping
- `easy` quick imports
- `pkg` non std modules
- `std` std modules
- `uix` cli or gui components
- `util` by uses
- `util/__init__.py` by 1-2 methods for each use
- `/*` by categories of uses

