import 'package:flutter/material.dart';
import '../models/q.dart';
import 'field.dart';

class QuestionCard extends StatefulWidget {
  final Q question;

  const QuestionCard({super.key, required this.question});

  @override
  State<QuestionCard> createState() => _QuestionCardState();
}

class _QuestionCardState extends State<QuestionCard> {
  final List<TextEditingController> _controllers = [];
  final List<FocusNode> _focusNodes = [];

  @override
  void initState() {
    super.initState();
    // Initialize controllers and focus nodes for each QField in the question
    for (var row in widget.question.rows) {
      for (var part in row.parts) {
        if (part is QField) {
          _controllers.add(TextEditingController());
          _focusNodes.add(FocusNode());
        }
      }
    }
  }

  @override
  void dispose() {
    for (var controller in _controllers) {
      controller.dispose();
    }
    for (var node in _focusNodes) {
      node.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Calculate the font size based on the number of rows, with a minimum of 36px
    final fontSize = 36.0 + (widget.question.rows.length * 2.0);
    
    // Find the maximum input length in the question
    int maxInputLength = 0;
    for (var row in widget.question.rows) {
      for (var part in row.parts) {
        if (part is QField && part.inputLength > maxInputLength) {
          maxInputLength = part.inputLength;
        }
      }
    }
    // Calculate width based on input length (n+1) * 40
    final fieldWidth = (maxInputLength + 1) * 40.0;

    return Card(
      child: Column(
        children: [
          // Tooltip ribbon on top of the card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            color: Colors.blue,
            child: Center(
              child: Text(
                'Tooltip: ${widget.question.rows.first.parts.whereType<QField>().first.tooltip}',
                style: TextStyle(fontSize: fontSize * 0.5, color: Colors.white),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: widget.question.rows.map((row) {
                return Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: row.parts.map((part) {
                    if (part is QString) {
                      return Text(
                        part.text,
                        style: TextStyle(fontSize: fontSize),
                      );
                    } else if (part is QField) {
                      int index = _controllers.length - 1;
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4.0),
                        child: SizedBox(
                          width: fieldWidth,
                          child: NumericInputField(
                            controller: _controllers[index],
                            maxLength: part.inputLength,
                            minValue: part.hasMin ? part.minValue! : -9223372036854775808,
                            maxValue: part.hasMax ? part.maxValue! : 9223372036854775807,
                            onChanged: (value) {
                              // Handle value change if needed
                            },
                            style: TextStyle(fontSize: fontSize * 1.5), // Increased font size for fields
                          ),
                        ),
                      );
                    }
                    return SizedBox.shrink();
                  }).toList(),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}
