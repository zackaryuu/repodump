import '../models/q.dart';

/// Abstract base class for all question generators
abstract class BaseQuestionGenerator {
  /// Generates a question model based on difficulty and weights
  /// 
  /// [difficulty] - The target difficulty level
  /// [numQ] - Number of questions to generate
  /// [weightMap] - Optional map of difficulty_priority to weight
  Q generateQuestion(int difficulty, int numQ, Map<String, int>? weightMap) {
    final function = selectDifficultyFunction(difficulty, weightMap);
    if (function == null) {
      throw Exception('No suitable difficulty function found for level $difficulty');
    }
    return function();
  }

  /// Get the difficulty functions for this generator
  Map<String, Q Function()> get difficultyFunctions => {};

  /// Helper method to select appropriate difficulty function
  Q Function()? selectDifficultyFunction(
    int targetDifficulty,
    Map<String, int>? weightMap,
  ) {
    final functions = difficultyFunctions;
    if (functions.isEmpty) return null;

    final functionDetails = functions.entries.map((entry) {
      final details = _parseDifficultyFunction(entry.key);
      final weight = weightMap?['${details['level']}_${details['priority']}'] ?? 1;
      return {
        'function': entry.value,
        'level': details['level'],
        'priority': details['priority'],
        'weight': weight
      };
    }).toList();

    final validFunctions = functionDetails
        .where((f) => (f['level'] as int) <= targetDifficulty)
        .toList();

    if (validFunctions.isEmpty) return null;

    validFunctions.sort((a, b) {
      final weightCompare = (b['weight'] as int).compareTo(a['weight'] as int);
      if (weightCompare != 0) return weightCompare;
      return (a['priority'] as int).compareTo(b['priority'] as int);
    });

    return validFunctions.first['function'] as Q Function();
  }

  Map<String, int> _parseDifficultyFunction(String functionName) {
    final parts = functionName.split('_');
    return {
      'level': int.parse(parts[0]),
      'priority': parts.length > 1 ? int.parse(parts[1]) : 1
    };
  }
}
