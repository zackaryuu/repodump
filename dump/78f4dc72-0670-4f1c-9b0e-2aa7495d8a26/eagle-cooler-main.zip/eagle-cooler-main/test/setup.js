"use strict";
// This file is used to set up the test environment
// Add any global test setup here
// Example: Set up any global variables or mocks
global.console = Object.assign({}, console);
