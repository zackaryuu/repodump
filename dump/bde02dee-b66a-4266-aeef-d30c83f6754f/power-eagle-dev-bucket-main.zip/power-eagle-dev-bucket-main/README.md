# power-eagle-dev-bucket

this project is a mod bucket for [power-eagle](https://github.com/eagle-cooler/power-eagle)

