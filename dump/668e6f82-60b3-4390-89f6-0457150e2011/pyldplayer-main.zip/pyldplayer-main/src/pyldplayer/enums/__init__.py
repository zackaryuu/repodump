from typing import TypeVar, Union

SOptional = Union[TypeVar("T"), None]
